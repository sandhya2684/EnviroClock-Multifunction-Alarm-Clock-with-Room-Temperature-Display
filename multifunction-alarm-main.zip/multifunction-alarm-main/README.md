# multifunction-alarm
Designed and developed a multifunction alarm system using embedded systems concepts.
Implemented alarm, timer, and buzzer alert functionalities for real-time operation.
Built using microcontroller-based hardware and embedded programming techniques.
